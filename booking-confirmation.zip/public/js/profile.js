// Handle profile form submission
document.getElementById('profileForm').addEventListener('submit', async function (event) {
    event.preventDefault();

    const formData = {
        name: document.getElementById('name').value,
        email: document.getElementById('email').value,
        phone: document.getElementById('phone').value,
        password: document.getElementById('password').value
    };

    try {
        const response = await fetch('/submit-profile', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(formData)
        });

        const data = await response.json();

        if (response.ok) {
            alert('Profile created successfully!');
            // Optionally redirect or update UI
        } else {
            throw new Error(data.error || 'Failed to create profile');
        }
    } catch (error) {
        console.error('Error:', error);
        alert(error.message);
    }
}); 