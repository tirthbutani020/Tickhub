# TickHub - Movie Ticket Booking System

## Background Images for Movies

To complete the movie trailer section, you need to create background images for each movie. Here's how to do it:

### Required Background Images

1. `movie1-bg.jpg` - For Pushpa-2
2. `movie2-bg.jpg` - For Sky Force
3. `movie3-bg.jpg` - For Fast X
4. `movie4-bg.jpg` - For Yeh Jawaani Hai Deewani
5. `movie5-bg.jpg` - For Baby John
6. `divine-bg.jpg` - For DIVINE
7. `aditya-bg.jpg` - For ADITYA GADHVI
8. `kailash-bg.jpg` - For KAILASH KHER
9. `monali-bg.jpg` - For MONALI THAKUR
10. `anuv-bg.jpg` - For ANUV JAIN

### How to Create Background Images

1. Find high-quality images related to each movie/artist
2. Resize them to 1920x1080 pixels (or similar 16:9 aspect ratio)
3. Apply a slight blur or darken effect to ensure text remains readable
4. Save them with the filenames listed above
5. Place them in the root directory of the project

### Image Sources

You can find suitable images from:
- Official movie posters
- Movie stills
- Concert photos
- Artist promotional images

### Alternative Solution

If you can't create the background images immediately, the system will fall back to a dark gradient background. You can add the images later without changing any code.

## Running the Application

1. Start the server:
   ```
   node server.js
   ```

2. Open the application in your browser:
   ```
   http://localhost:5000
   ```

## Features

- Movie and event listings
- Seat booking system
- User authentication
- Movie details with trailers
- Responsive design 